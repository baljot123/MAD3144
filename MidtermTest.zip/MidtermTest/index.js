function login()
{
  if(document.getElementById('name').value == "test" && document.getElementById('password').value == "test")
  {
    sessionStorage.setItem('displayuser', document.getElementById('name').value);
    window.open("bank.html");
  }
  else {
    alert("Wrong username or password");
  }
}
