var sav = 1000.0;
var check = 1000.0;
var selectedFrom = "null";
var selectedTo = "null";
document.getElementById("otherUser").style.display = "none";

document.getElementById("currentBalance").innerHTML = "saving = " + sav + "$ checking =" + check + "$"

document.getElementById('displayName').innerHTML = "WELCOME: " + sessionStorage.getItem('displayuser');

function checkfrom{

  var a = document.getElementById("savefrom");
    var checkBox = document.getElementById("checkFrom");
      if (checkBox.checked == true){
         a.checked = false;
          selectedFrom = "checking"
      }

}
function savefrom{

  var a = document.getElementById("checkFrom");
    var checkBox = document.getElementById("savefrom");
      if (checkBox.checked == true){
         a.checked = false;
          selectedFrom = "saving"
      }

}
